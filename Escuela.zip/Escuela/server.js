const express = require('express');
const dotenv = require('dotenv');
const seed = require('./seed'); // Importa el seed

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

// Llamar el seed al iniciar el servidor
seed.runSeed();

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
